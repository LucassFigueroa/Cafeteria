# CoffeeFlow – Pruebas JUnit 5 + Selenium

Casos automatizados del plan de pruebas:

| Clase | Caso | Escenarios |
|---|---|---|
| `CP14ConfirmarVentaTest` | CP-14 Confirmar venta | 14.1 registra la venta y descuenta stock · 14.2 persiste tras recargar |
| `CP15ValidacionVentaTest` | CP-15 Validaciones de la venta | 15.1 no supera el stock · 15.2 producto inactivo / carrito vacío |
| `CP02CredencialesInvalidasTest` | CP-02 Credenciales inválidas | 02.1 contraseña incorrecta · 02.2 usuario vacío |
| `CP13CalculoTotalesTest` | CP-13 Cálculo de totales | 13.1 subtotales y total CLP |
| `CP04ControlAccesoTest` | CP-04 Acceso sin sesión | /productos y /reportes (**falla: defecto conocido**) |
| `CP17DatosCorruptosTest` | CP-17 Datos corruptos | 17.1 recuperación (**falla: defecto conocido**) |

Resultado esperado hoy: 10 pruebas, 7 aprobadas y 3 reprobadas. Las reprobadas evidencian los defectos
`authGuard = () => true` (app.routes.ts) y `JSON.parse` sin try/catch (cafeteria.service.ts); pasan a verde al corregirlos.

## Ejecutar

1. Levantar el front: `cd front` → `npm start` (queda en http://localhost:4200).
2. En otra terminal: `cd pruebas-selenium` → `mvn test`
   - Sin ventana de Chrome: `mvn test -Dheadless=true`
   - Otra URL: `mvn test -DbaseUrl=http://localhost:4200`

Requisitos: Java 17+, Maven y Google Chrome (Selenium Manager descarga el driver solo).
Las capturas quedan en `target/evidencias/` y los reportes en `target/surefire-reports/`.
